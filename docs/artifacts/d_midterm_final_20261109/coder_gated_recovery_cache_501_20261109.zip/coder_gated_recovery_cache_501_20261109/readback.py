import argparse
import json
from pathlib import Path
import sys


def main() -> int:
    parser = argparse.ArgumentParser(description="Read back one frozen gated cache generation.")
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--bundle", type=Path, required=True)
    parser.add_argument("--cache", type=Path, required=True)
    parser.add_argument("--request", type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str((args.repo / "src").resolve()))
    from oss_mentor.gated_scoring import CachedGatedScorer
    from oss_mentor.services.profile_service import as_developer_profile_v2

    request = json.loads(args.request.read_text(encoding="utf-8"))
    scorer = CachedGatedScorer(args.bundle, args.cache).bind_enhanced_profile(
        request.get("enhanced_profile")
    )
    batch = scorer.score(
        profile=as_developer_profile_v2(request["profile"]),
        developer_key=request["developer_key"],
        candidates=request["candidates"],
    )
    result = {
        "scores": len(batch.scores),
        "unique_task_ids": len({item.task_candidate_id for item in batch.scores}),
        "model_version": batch.model_version,
        "profile_mode": batch.profile_mode,
        "coverage_states": sorted({item.coverage_state for item in batch.scores}),
        "warnings": list(batch.warnings),
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["scores"] == 501 and result["unique_task_ids"] == 501 else 2


if __name__ == "__main__":
    raise SystemExit(main())
