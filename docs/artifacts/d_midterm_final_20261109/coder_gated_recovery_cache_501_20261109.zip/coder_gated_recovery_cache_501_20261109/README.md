# OSS-Mentor gated recovery cache delivery

This package contains a regenerated live gated cache for the final midterm
acceptance. It is not the superseded ZIP and does not reuse its SHA-256.

## Identity

- Context key: `bcbe441091cabe3bb9cef79f263b1938488af29dd82f24a8f1c2eb410e451de5`
- Generation: `454625782adc45a38cc2d7a53c532d4f`
- Model version: `coder-gated-marginal_positive-s20261102`
- Feature schema: `coder-gated-128+16-v1`
- Candidates: `501`
- As of: `2026-11-09T14:23:51.942999+00:00`
- Expires at: `2026-11-10T14:23:24.264691+00:00`
- `history_complete=false`
- `cold_start=false`
- Collection status: `bounded_public_sample`

## Directory structure

```text
coder_gated_recovery_cache_501_20261109/
  README.md
  SHA256SUMS.txt
  delivery_manifest.json
  readback.py
  readback.json
  request.json
  worker_status.json
  cache/
    bcbe441091cabe3bb9cef79f263b1938488af29dd82f24a8f1c2eb410e451de5.current.json
    generations/
      454625782adc45a38cc2d7a53c532d4f/
        bcbe441091cabe3bb9cef79f263b1938488af29dd82f24a8f1c2eb410e451de5.json
        bcbe441091cabe3bb9cef79f263b1938488af29dd82f24a8f1c2eb410e451de5.npz
```

## Read-back

From the extracted package directory:

```powershell
$repo = '<OSS-Mentor checkout>'
$bundle = '<frozen gated bundle containing manifest.json and weights.npz>'
$env:PYTHONPATH = Join-Path $repo 'src'
python .\readback.py `
  --repo $repo `
  --bundle $bundle `
  --cache .\cache `
  --request .\request.json
```

Expected result:

```json
{
  "scores": 501,
  "unique_task_ids": 501,
  "model_version": "coder-gated-marginal_positive-s20261102",
  "profile_mode": "prepared_profile_gated",
  "coverage_states": ["gated_prepared_context"],
  "warnings": ["gated_scores_are_not_success_probabilities"]
}
```

## Start the platform with this cache

```powershell
$repo = '<OSS-Mentor checkout>'
$bundle = '<frozen gated bundle>'
$env:PYTHONPATH = Join-Path $repo 'src'
python -m oss_mentor serve-api `
  --database '<isolated.sqlite3>' `
  --gated-bundle $bundle `
  --gated-cache .\cache `
  --refresh-interval-seconds 0
```

The server must return `100/100` `coder_gated` rankings with
`profile_mode=prepared_profile_gated` and `coverage_state=gated_prepared_context`.
