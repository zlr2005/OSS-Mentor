# OSS-Mentor 推荐算法离线评估 v0.3

## 概览

- 通道：`growth`
- 画像：`growth_python_crossplatform`
- 当前评估版本：`developer-task-match-v0.3`
- 标注行数：1
- 标注任务数：1
- 标注员数：1
- 双人复标任务数：0
- 候选任务数：48
- 版本晋级门禁：未通过

## 标注验收

- 至少 30 个任务：未通过
- 至少 2 名标注员：未通过
- 至少 10 个双人复标任务：未通过
- 无开发期伪标注员：通过
- 标注总体验收：未通过

## 版本晋级门禁

- annotation_acceptance：未通过
- platform_mismatch_rate_zero：通过
- unavailable_task_leakage_zero：通过
- critical_skill_mismatch_not_worse：通过
- ndcg_at_10_not_worse：通过
- precision_at_5_not_worse：通过

## 指标对比

| 版本 | P@5 | P@10 | R@5 | R@10 | NDCG@10 | MRR | 关键技能不匹配率 | 仓库多样性 | 空结果率 |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| `developer-task-match-v0.1` | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 | 4 | 0.000 |
| `developer-task-match-v0.2` | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 | 4 | 0.000 |
| `developer-task-match-v0.3` | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 | 4 | 0.000 |

## Top 10 变化

- `developer-task-match-v0.1_to_developer-task-match-v0.2`：新增 0，移出 0，排名移动 7
- `developer-task-match-v0.2_to_developer-task-match-v0.3`：新增 0，移出 0，排名移动 7

## 当前 Top 10

| 排名 | 任务 | 分数 | 标注适配 | 主要原因 |
|---:|---|---:|---:|---|
| 1 | `vercel/next.js#95745` | 65.83 | - | skill_coverage=0.91, preferred_language, preferred_task_type, stretch_target=1, v0.3_component_scoring |
| 2 | `matplotlib/matplotlib#17479` | 63.55 | - | skill_coverage=0.82, preferred_language, preferred_task_type, stretch_target=1, v0.3_component_scoring |
| 3 | `nodejs/undici#4143` | 62.57 | - | skill_coverage=0.87, preferred_language, preferred_task_type, stretch_target=1, v0.3_component_scoring, diversity_penalty=0.5 |
| 4 | `vercel/next.js#38863` | 60.57 | - | skill_coverage=0.87, preferred_language, preferred_task_type, stretch_target=1, v0.3_component_scoring, diversity_penalty=2.5 |
| 5 | `nodejs/undici#4144` | 60.07 | - | skill_coverage=0.87, preferred_language, preferred_task_type, stretch_target=1, v0.3_component_scoring, diversity_penalty=3.0 |
| 6 | `matplotlib/matplotlib#8088` | 59.05 | - | skill_coverage=0.82, preferred_language, preferred_task_type, stretch_target=1, v0.3_component_scoring, diversity_penalty=4.5 |
| 7 | `vercel/next.js#41281` | 57.57 | - | skill_coverage=0.87, preferred_language, preferred_task_type, stretch_target=1, v0.3_component_scoring, diversity_penalty=5.5 |
| 8 | `scikit-learn/scikit-learn#22827` | 57.20 | - | skill_coverage=1.00, preferred_language, preferred_task_type, stretch_target=1, v0.3_component_scoring |
| 9 | `nodejs/undici#4287` | 57.07 | - | skill_coverage=0.87, preferred_language, preferred_task_type, stretch_target=1, v0.3_component_scoring, diversity_penalty=6.0 |
| 10 | `vercel/next.js#42846` | 55.07 | - | skill_coverage=0.87, preferred_language, preferred_task_type, stretch_target=1, v0.3_component_scoring, diversity_penalty=8.0 |

## 覆盖、暴露与新鲜度

### `developer-task-match-v0.1`

- 有结果画像覆盖率：1.000
- 平均推荐数量：10
- 低库存画像比例：0.000
- 90 天内新鲜度：0.700
- 不可用任务泄漏率：0.000
- 仓库暴露：{'matplotlib/matplotlib': 2, 'nodejs/undici': 3, 'scikit-learn/scikit-learn': 1, 'vercel/next.js': 4}
- 任务类型暴露：{'bug_fix': 5, 'build_tooling': 1, 'documentation': 1, 'feature': 5, 'testing': 1}
- 语言暴露：{'JavaScript': 7, 'Python': 3}
### `developer-task-match-v0.2`

- 有结果画像覆盖率：1.000
- 平均推荐数量：10
- 低库存画像比例：0.000
- 90 天内新鲜度：0.700
- 不可用任务泄漏率：0.000
- 仓库暴露：{'matplotlib/matplotlib': 2, 'nodejs/undici': 3, 'scikit-learn/scikit-learn': 1, 'vercel/next.js': 4}
- 任务类型暴露：{'bug_fix': 5, 'build_tooling': 1, 'documentation': 1, 'feature': 5, 'testing': 1}
- 语言暴露：{'JavaScript': 7, 'Python': 3}
### `developer-task-match-v0.3`

- 有结果画像覆盖率：1.000
- 平均推荐数量：10
- 低库存画像比例：0.000
- 90 天内新鲜度：0.700
- 不可用任务泄漏率：0.000
- 仓库暴露：{'matplotlib/matplotlib': 2, 'nodejs/undici': 3, 'scikit-learn/scikit-learn': 1, 'vercel/next.js': 4}
- 任务类型暴露：{'bug_fix': 5, 'build_tooling': 1, 'documentation': 1, 'feature': 5, 'testing': 1}
- 语言暴露：{'JavaScript': 7, 'Python': 3}

## Bootstrap 95% 置信区间

### `developer-task-match-v0.1`
- precision_at_5：[0.000, 0.000]
- precision_at_10：[0.000, 0.000]
- recall_at_5：[0.000, 0.000]
- recall_at_10：[0.000, 0.000]
- ndcg_at_5：[0.000, 0.000]
- ndcg_at_10：[0.000, 0.000]
- mrr：[0.000, 0.000]
### `developer-task-match-v0.2`
- precision_at_5：[0.000, 0.000]
- precision_at_10：[0.000, 0.000]
- recall_at_5：[0.000, 0.000]
- recall_at_10：[0.000, 0.000]
- ndcg_at_5：[0.000, 0.000]
- ndcg_at_10：[0.000, 0.000]
- mrr：[0.000, 0.000]
### `developer-task-match-v0.3`
- precision_at_5：[0.000, 0.000]
- precision_at_10：[0.000, 0.000]
- recall_at_5：[0.000, 0.000]
- recall_at_10：[0.000, 0.000]
- ndcg_at_5：[0.000, 0.000]
- ndcg_at_10：[0.000, 0.000]
- mrr：[0.000, 0.000]

## 权重变化依据

- v0.2 raises the skill-coverage contribution to reduce critical skill misses.
- v0.2 keeps explicit platform requirements as hard filters.
- v0.2 applies repository-balanced top-k selection to reduce concentration.

## 警告

- `annotation_without_candidate`: example/demo#1
- `recommendation_without_annotation`: vercel/next.js#95745
- `recommendation_without_annotation`: matplotlib/matplotlib#8088
- `recommendation_without_annotation`: matplotlib/matplotlib#17479
- `recommendation_without_annotation`: nodejs/undici#4143
- `recommendation_without_annotation`: nodejs/undici#4144
- `recommendation_without_annotation`: nodejs/undici#4287
- `recommendation_without_annotation`: vercel/next.js#38863
- `recommendation_without_annotation`: vercel/next.js#41281
- `recommendation_without_annotation`: vercel/next.js#42846
- `recommendation_without_annotation`: scikit-learn/scikit-learn#22827
- `recommendation_without_annotation`: vercel/next.js#95745
- `recommendation_without_annotation`: matplotlib/matplotlib#8088
- `recommendation_without_annotation`: nodejs/undici#4143
- `recommendation_without_annotation`: scikit-learn/scikit-learn#22827
- `recommendation_without_annotation`: matplotlib/matplotlib#17479
- `recommendation_without_annotation`: nodejs/undici#4144
- `recommendation_without_annotation`: vercel/next.js#38863
- `recommendation_without_annotation`: nodejs/undici#4287
- `recommendation_without_annotation`: vercel/next.js#41281
- `recommendation_without_annotation`: vercel/next.js#42846
- `recommendation_without_annotation`: vercel/next.js#95745
- `recommendation_without_annotation`: matplotlib/matplotlib#17479
- `recommendation_without_annotation`: nodejs/undici#4143
- `recommendation_without_annotation`: vercel/next.js#38863
- `recommendation_without_annotation`: nodejs/undici#4144
- `recommendation_without_annotation`: matplotlib/matplotlib#8088
- `recommendation_without_annotation`: vercel/next.js#41281
- `recommendation_without_annotation`: scikit-learn/scikit-learn#22827
- `recommendation_without_annotation`: nodejs/undici#4287
- `recommendation_without_annotation`: vercel/next.js#42846

## 限制

- The report uses manually annotated samples and does not train a model.
- Small annotation sets can make diversity and precision metrics unstable.
- Bootstrap intervals quantify annotation-sample uncertainty and are not a substitute for an external test set.
- Feedback events are summarized separately and are not used for automatic reranking.
